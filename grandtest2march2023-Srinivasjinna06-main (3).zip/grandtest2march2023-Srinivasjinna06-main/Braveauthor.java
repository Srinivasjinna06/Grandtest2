import java.util.*;
public class Braveauthor{
  public static void main(String[] args)
  {
    Scanner s=new Scanner(System.in);
    System.out.println("Enter the string:");
    String str=s.nextLine();
    int count[]=new int[26];

    for(int i=0;i<str.length();i++)
      {
        count[str.charAt(i)-'a']++;
      }
    int max=count[0];
    for(int i=1;i<26;i++)
      {
        if(count[i]>max)
        {
          max=count[i];
        }
      }
    int sum=0;
     for(int i=0;i<26;i++)
       {
         if(count[i]!=max)
         {
           sum+=count[i];
         }
       }
    if(sum==max)
    {
      System.out.println("Yes");
    }
    else
    {
      System.out.println("No");
    }
  }
}