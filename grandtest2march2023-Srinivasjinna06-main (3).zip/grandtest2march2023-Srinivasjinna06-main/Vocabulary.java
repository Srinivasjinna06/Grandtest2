import java.util.*;
public class Vocabulary{
  public static void main(String[] args){
    Scanner s=new Scanner(System.in);
    System.out.println("enter the noun:");
    String noun=s.nextLine();
    System.out.println("Enter the adjective:");
    String adjective=s.nextLine();
    System.out.println("Enter the activity:");
    String activity=s.nextLine();
    String output= noun+" was really "+adjective+" today. We learned how to write "+activity+" today. I can't wait for tomorrow! ";
    System.out.println(output);
  }
}