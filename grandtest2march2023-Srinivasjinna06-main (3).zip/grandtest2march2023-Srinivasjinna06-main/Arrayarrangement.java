import java.util.*;
public class Arrayarrangement{
  public static void main(String[] args){
    
  
  Scanner s=new Scanner(System.in);
  System.out.println("Enter the array size");
  int n=s.nextInt();
  int arr[]=new int[n];
  
    for(int i=0;i<n;i++)
    {
      arr[i]=s.nextInt();
    }
   System.out.println("Enter the value from that change sequence of array ");
    int m=s.nextInt();
    int temp[]=new int[m];
    for(int i=0;i<m;i++)
      {
        temp[i]=arr[i];
      }
    
    for(int i=m;i<n;i++)
      {
        arr[i-m]=arr[i];
      }
    
     for(int i=0;i<m;i++)
      {
        arr[n-m+i]=temp[i];
      }
    System.out.println("The Changed array is: ");
      for(int i=0;i<n;i++)
      {
      System.out.print(arr[i]+" ");
      }
   
  }
}