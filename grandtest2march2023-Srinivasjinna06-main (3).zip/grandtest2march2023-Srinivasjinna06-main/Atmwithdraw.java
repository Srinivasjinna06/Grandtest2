import java.util.*;
public class Atmwithdraw{
  public static void main(String[] args)
    {
    Scanner s=new Scanner(System.in);
    System.out.println("Enter the Amount:");
    int amount=s.nextInt();

    if(amount%100!=0)
    {
      System.out.println("Entered amount should be multiple of 100 ");
    }
    else if(amount<=100 && amount<=10000)
    {
      System.out.println("Entered amount should be positive and only Integers.");
    }
    else
    {
      int notes_500=amount/500;
      amount%=500;
      int notes_200=amount/200;
      amount%=200;
      int notes_100=amount/100;
      amount%=100;
      int sum=notes_500+notes_200+notes_100;
      System.out.println(sum);
    }
    }
}