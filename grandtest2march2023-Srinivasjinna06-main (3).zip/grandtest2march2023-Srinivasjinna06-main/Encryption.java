import java.util.*;
public class Encryption
  {
    public static void main(String[] args){
      Scanner s=new Scanner(System.in);
      System.out.println("Enter the string for Encryption:");
      String str=s.nextLine();
      char[] ch=str.toCharArray();
      String space=" ";
      for(int i=0;i<ch.length;i=i+2)
        {
          System.out.print(ch[i]);
        }
      for(int i=1;i<ch.length;i=i+2)
        {
          space+=ch[i];
        }
      System.out.println(space);
    }
  }